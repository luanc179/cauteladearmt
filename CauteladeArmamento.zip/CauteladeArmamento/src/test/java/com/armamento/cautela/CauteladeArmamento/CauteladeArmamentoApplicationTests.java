package com.armamento.cautela.CauteladeArmamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CauteladeArmamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
